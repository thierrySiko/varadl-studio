import ReactFlow, {
  Background,
  Controls,
  MarkerType,
  Position,
} from "reactflow";
import type { Edge, Node } from "reactflow";
import "reactflow/dist/style.css";

import { getLayoutedElements } from "./graph-layout";

import type {
  Architecture,
  ArchitecturalElement,
  Component,
  Connector,
  Constraint,
} from "../model/varadl-types";

interface Props {
  productElements: ArchitecturalElement[];
  architecture?: Architecture | null;
}

function isComponent(element: ArchitecturalElement): element is Component {
  return element.kind === "component";
}

function isConnector(element: ArchitecturalElement): element is Connector {
  return element.kind === "connector";
}

function constraintColor(type: Constraint["type"]): string {
  return type === "requires" ? "#16a34a" : "#dc2626";
}

function constraintLabel(type: Constraint["type"]): string {
  return type === "requires" ? "requires" : "excludes";
}

export default function GraphViewReactFlow({
  productElements,
  architecture,
}: Props) {
  const components = productElements.filter(isComponent);
  const connectors = productElements.filter(isConnector);

  const componentNames = new Set(components.map((c) => c.name));

  const rawNodes: Node[] = components.map((component) => ({
    id: component.name,
    position: { x: 0, y: 0 },
    sourcePosition: Position.Bottom,
    targetPosition: Position.Top,
    data: {
      label: (
        <div>
          <div style={{ fontWeight: 700, marginBottom: 4 }}>{component.name}</div>
          <div style={{ fontSize: 11, color: "#475569" }}>
            {component.ports.length > 0
              ? component.ports.map((p) => p.name).join(", ")
              : "Aucun port"}
          </div>
        </div>
      ),
    },
    style: {
      border: "1px solid #94a3b8",
      borderRadius: 10,
      background: "#ffffff",
      padding: 10,
      width: 220,
      boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
    },
  }));

  const rawEdges: Edge[] = [];

  connectors.forEach((connector, index) => {
    rawEdges.push({
      id: `connect-${index}`,
      source: connector.sourceComponent,
      target: connector.targetComponent,
      label: `${connector.sourcePort} → ${connector.targetPort}`,
      type: "smoothstep",
      style: {
        stroke: "#64748b",
        strokeWidth: 2,
      },
      labelStyle: {
        fill: "#334155",
        fontSize: 11,
        fontWeight: 600,
      },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: "#64748b",
      },
    });
  });

  if (architecture) {
    architecture.constraints
      .filter(
        (constraint) =>
          componentNames.has(constraint.source) &&
          componentNames.has(constraint.target)
      )
      .forEach((constraint, index) => {
        const color = constraintColor(constraint.type);

        rawEdges.push({
          id: `constraint-${index}`,
          source: constraint.source,
          target: constraint.target,
          label: constraintLabel(constraint.type),
          type: "smoothstep",
          animated: false,
          style: {
            stroke: color,
            strokeWidth: 2,
            strokeDasharray: "6 4",
          },
          labelStyle: {
            fill: color,
            fontSize: 11,
            fontWeight: 700,
          },
          markerEnd: {
            type: MarkerType.ArrowClosed,
            color,
          },
        });
      });
  }

  const { nodes, edges } = getLayoutedElements(rawNodes, rawEdges, "TB");

  return (
    <div
      style={{
        height: 560,
        marginTop: 20,
        border: "1px solid #ddd",
        borderRadius: 8,
        overflow: "hidden",
        background: "#f8fafc",
      }}
    >
      <ReactFlow nodes={nodes} edges={edges} fitView>
        <Background />
        <Controls />
      </ReactFlow>
    </div>
  );
}