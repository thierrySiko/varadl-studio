import ReactFlow, { Background, Controls, MarkerType } from "reactflow";
import type { Node, Edge } from "reactflow";
import "reactflow/dist/style.css";

import { getLayoutedElements } from "./graph-layout";

import type {
  Architecture,
  VariationPoint,
  Variant,
} from "../model/varadl-types";

interface Props {
  architecture: Architecture;
}

export default function SPLGraphView({ architecture }: Props) {

  const nodes: Node[] = [];
  const edges: Edge[] = [];

  let nodeIndex = 0;

  architecture.variationPoints.forEach((vp: VariationPoint) => {

    const vpId = `vp-${vp.name}`;

    nodes.push({
      id: vpId,
      position: { x: 0, y: 0 },
      data: { label: `VP: ${vp.name}` },
      style: {
        background: "#eef2ff",
        border: "1px solid #6366f1",
        borderRadius: 8,
        padding: 10,
        fontWeight: 700,
      },
    });

    vp.variants.forEach((variant: Variant) => {

      const variantId = `variant-${variant.name}`;

      nodes.push({
        id: variantId,
        position: { x: 0, y: 0 },
        data: { label: `Variant: ${variant.name}` },
        style: {
          background: "#ecfeff",
          border: "1px solid #0891b2",
          borderRadius: 8,
          padding: 10,
        },
      });

      edges.push({
        id: `edge-vp-${nodeIndex++}`,
        source: vpId,
        target: variantId,
        type: "smoothstep",
        markerEnd: { type: MarkerType.ArrowClosed },
      });

      variant.elements
        .filter(e => e.kind === "component")
        .forEach((component) => {

          const compId = `comp-${component.name}`;

          nodes.push({
            id: compId,
            position: { x: 0, y: 0 },
            data: { label: component.name },
            style: {
              background: "#f8fafc",
              border: "1px solid #94a3b8",
              borderRadius: 8,
              padding: 10,
            },
          });

          edges.push({
            id: `edge-var-${nodeIndex++}`,
            source: variantId,
            target: compId,
            type: "smoothstep",
            markerEnd: { type: MarkerType.ArrowClosed },
          });

        });

    });

  });

  const layout = getLayoutedElements(nodes, edges, "TB");

  return (

    <div
      style={{
        height: 500,
        marginTop: 30,
        border: "1px solid #ddd",
        borderRadius: 8,
      }}
    >

      <ReactFlow
        nodes={layout.nodes}
        edges={layout.edges}
        fitView
      >

        <Background />
        <Controls />

      </ReactFlow>

    </div>

  );
}